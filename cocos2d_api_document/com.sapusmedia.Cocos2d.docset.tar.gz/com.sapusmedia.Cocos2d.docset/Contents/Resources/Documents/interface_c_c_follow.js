var interface_c_c_follow =
[
    [ "actionWithTarget:", "interface_c_c_follow.html#a38cffdc56dc7d0a1b1942f33133e3fb4", null ],
    [ "actionWithTarget:worldBoundary:", "interface_c_c_follow.html#aa431e577396f063fcb032c66539c98ca", null ],
    [ "initWithTarget:", "interface_c_c_follow.html#ad7aacfebff2323e38f0268293890c59e", null ],
    [ "initWithTarget:worldBoundary:", "interface_c_c_follow.html#a2c3ec0bcb450878f417b10a0dd751e25", null ],
    [ "bottomBoundary", "interface_c_c_follow.html#ab064431de84b5714079b8497947905be", null ],
    [ "boundaryFullyCovered", "interface_c_c_follow.html#a9c8ad8b15485a739a657604aa3699974", null ],
    [ "followedNode_", "interface_c_c_follow.html#ae43821a33173744db154c09f9658028f", null ],
    [ "fullScreenSize", "interface_c_c_follow.html#a8c666a0f9b42d848b244e9494dddadf1", null ],
    [ "halfScreenSize", "interface_c_c_follow.html#aed502a2e5fe6d2a11eb281242aee70f1", null ],
    [ "leftBoundary", "interface_c_c_follow.html#a0afe2aea3a0fe017812e20d628e4766c", null ],
    [ "rightBoundary", "interface_c_c_follow.html#a052c8688d8514db767680fc85a22aff4", null ],
    [ "topBoundary", "interface_c_c_follow.html#ae31fc04f9746b6224b3bfddaa0f48721", null ],
    [ "boundarySet", "interface_c_c_follow.html#a2e8c9c693c6996f161a091b1dd6bf144", null ]
];