var interface_c_c_animation_cache =
[
    [ "addAnimation:name:", "interface_c_c_animation_cache.html#ab137bd516a078ba912d7dcb3762107b6", null ],
    [ "addAnimationsWithDictionary:", "interface_c_c_animation_cache.html#a1005b4ef347685bf5860231331c09f84", null ],
    [ "addAnimationsWithFile:", "interface_c_c_animation_cache.html#a1312bc730d9abfb38c153489bd96bbd6", null ],
    [ "animationByName:", "interface_c_c_animation_cache.html#aa9322c5646aaf8488853868983ecf4d7", null ],
    [ "purgeSharedAnimationCache", "interface_c_c_animation_cache.html#ad6998e692e308000fb2362e4a3d30ed0", null ],
    [ "removeAnimationByName:", "interface_c_c_animation_cache.html#af9890fd4eadff83febe5aac30f9f1709", null ],
    [ "sharedAnimationCache", "interface_c_c_animation_cache.html#adf619f2724f074683693bb4374a55571", null ],
    [ "animations_", "interface_c_c_animation_cache.html#aea07c23c7d7de5989041b407a0afb7d1", null ]
];