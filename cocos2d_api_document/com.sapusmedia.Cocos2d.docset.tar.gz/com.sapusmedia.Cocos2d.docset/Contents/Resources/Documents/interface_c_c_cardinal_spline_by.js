var interface_c_c_cardinal_spline_by =
[
    [ "startPosition_", "interface_c_c_cardinal_spline_by.html#abdd75209f11e702e6d1b037480a9ca90", null ]
];