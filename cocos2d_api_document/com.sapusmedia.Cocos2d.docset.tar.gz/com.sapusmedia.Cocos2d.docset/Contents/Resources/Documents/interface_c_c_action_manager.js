var interface_c_c_action_manager =
[
    [ "addAction:target:paused:", "interface_c_c_action_manager.html#acaa9759ef06e75a48d82e01b673f2eb4", null ],
    [ "DEPRECATED_ATTRIBUTE", "interface_c_c_action_manager.html#aa59391b28d619b1cc9c8c8013839f776", null ],
    [ "getActionByTag:target:", "interface_c_c_action_manager.html#a7442b773fe5b81561ddc9ae3006a99f2", null ],
    [ "numberOfRunningActionsInTarget:", "interface_c_c_action_manager.html#a4961d5047b2a1a31d8d314d75382afae", null ],
    [ "pauseAllRunningActions", "interface_c_c_action_manager.html#ad4c0025b0fcd31689ab77c011d842296", null ],
    [ "pauseTarget:", "interface_c_c_action_manager.html#aa98d2613d9f225a6d65cb4318022aeff", null ],
    [ "removeAction:", "interface_c_c_action_manager.html#a6f10c668c171f7858b9202c1be97db40", null ],
    [ "removeActionByTag:target:", "interface_c_c_action_manager.html#a98c01e9ff6ad3db964d13c0daec8eb8c", null ],
    [ "removeAllActions", "interface_c_c_action_manager.html#a221135cfd89d31e862e2a2b8cbd3b0ff", null ],
    [ "removeAllActionsFromTarget:", "interface_c_c_action_manager.html#af32c4dcefa469ecece2541d0f405b517", null ],
    [ "resumeTarget:", "interface_c_c_action_manager.html#aa08024e5bd9c8d606dce13acb03ede6b", null ],
    [ "resumeTargets:", "interface_c_c_action_manager.html#a7e0caab635e5824f8772c72728cb9d1e", null ],
    [ "currentTarget", "interface_c_c_action_manager.html#a863f13a4c8bae7d26a0524dd18a1cfd3", null ],
    [ "currentTargetSalvaged", "interface_c_c_action_manager.html#add665102da7e76098785b6078f3bade7", null ],
    [ "targets", "interface_c_c_action_manager.html#a24bbe7c5c87bf4cfee6b8f48b5078d6b", null ]
];