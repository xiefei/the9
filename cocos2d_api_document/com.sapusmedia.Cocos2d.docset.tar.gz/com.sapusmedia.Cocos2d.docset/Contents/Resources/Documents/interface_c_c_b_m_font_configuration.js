var interface_c_c_b_m_font_configuration =
[
    [ "configurationWithFNTFile:", "interface_c_c_b_m_font_configuration.html#ad6edd555bbb3e20d9416cd627db7c4e0", null ],
    [ "initWithFNTfile:", "interface_c_c_b_m_font_configuration.html#aba89ad3156aff35ff8e21c4d4f47be01", null ],
    [ "atlasName_", "interface_c_c_b_m_font_configuration.html#a15637f1aee3890cf2ed64f787eb1bbb4", null ],
    [ "commonHeight_", "interface_c_c_b_m_font_configuration.html#a68539ff1edeb4d68b5639ab1d6fdd8e8", null ],
    [ "fontDefDictionary_", "interface_c_c_b_m_font_configuration.html#af8f816d6a5d42e352814ecb9199e7703", null ],
    [ "kerningDictionary_", "interface_c_c_b_m_font_configuration.html#a7a8f9a4712d3cbd04b1d058f80d72ddb", null ],
    [ "padding_", "interface_c_c_b_m_font_configuration.html#ae90bc035dd6890296caa4bb5acc7bafc", null ],
    [ "atlasName", "interface_c_c_b_m_font_configuration.html#a88b7cc1fe74609247a09bb99b90f74eb", null ]
];