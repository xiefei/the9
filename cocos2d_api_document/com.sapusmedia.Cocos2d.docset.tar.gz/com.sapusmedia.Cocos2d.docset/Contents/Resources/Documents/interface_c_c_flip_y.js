var interface_c_c_flip_y =
[
    [ "actionWithFlipY:", "interface_c_c_flip_y.html#ae7fab176ad843f9ba3c06a59b4bb8bf7", null ],
    [ "initWithFlipY:", "interface_c_c_flip_y.html#a46b46d84889e472205ab53f89f2fc278", null ],
    [ "flipY", "interface_c_c_flip_y.html#a71e1d2921b6e2c34351d486e2fa91b82", null ]
];