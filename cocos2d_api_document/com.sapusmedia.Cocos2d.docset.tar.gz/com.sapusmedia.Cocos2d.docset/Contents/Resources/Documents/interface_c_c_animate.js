var interface_c_c_animate =
[
    [ "actionWithAnimation:", "interface_c_c_animate.html#a509b8a655b24ee34615bbe2eb65f8db0", null ],
    [ "actionWithAnimation:restoreOriginalFrame:", "interface_c_c_animate.html#aad0e7d923d64f361cfb9e7789ce5d247", null ],
    [ "actionWithDuration:animation:restoreOriginalFrame:", "interface_c_c_animate.html#a558bf0ba5d04a167e7678c4e992cb9e6", null ],
    [ "initWithAnimation:", "interface_c_c_animate.html#aac954dac6923a10d4467363842a50e6b", null ],
    [ "initWithAnimation:restoreOriginalFrame:", "interface_c_c_animate.html#aabe0620adbaca30d9121f0581f7b2adb", null ],
    [ "initWithDuration:animation:restoreOriginalFrame:", "interface_c_c_animate.html#a3dfdda3854665633c552ec36b9214cd7", null ],
    [ "animation_", "interface_c_c_animate.html#a69f62bb2f660f09fa9bc82e1917252f4", null ],
    [ "executedLoops_", "interface_c_c_animate.html#a3af44f2473639fbc9213aa349bba9155", null ],
    [ "nextFrame_", "interface_c_c_animate.html#a78c3c9a779b381be83417c3e249829ba", null ],
    [ "origFrame_", "interface_c_c_animate.html#aa1c3752a4414fb3db1e4b1cc75609c4a", null ],
    [ "splitTimes_", "interface_c_c_animate.html#a3e9776b0c46dfe112a5685f46568a7ba", null ],
    [ "animation", "interface_c_c_animate.html#ae4a9ffbb8c0b5496a5c20c250ef4ac83", null ]
];