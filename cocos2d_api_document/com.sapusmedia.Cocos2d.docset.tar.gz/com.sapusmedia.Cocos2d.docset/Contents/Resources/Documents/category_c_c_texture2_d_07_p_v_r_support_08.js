var category_c_c_texture2_d_07_p_v_r_support_08 =
[
    [ "initWithPVRFile:", "category_c_c_texture2_d_07_p_v_r_support_08.html#aad368c7ee5b5b81725772b8753a2aa51", null ],
    [ "PVRImagesHavePremultipliedAlpha:", "category_c_c_texture2_d_07_p_v_r_support_08.html#a129338ae7dc5eccd0bc97b8af0a81b2a", null ]
];