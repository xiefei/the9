var interface_c_c_grabber =
[
    [ "afterRender:", "interface_c_c_grabber.html#afde826ab4fe0daca1d04cc699afc7c3e", null ],
    [ "beforeRender:", "interface_c_c_grabber.html#ad823b9a1643b75353453c834f41e6e54", null ],
    [ "grab:", "interface_c_c_grabber.html#a630672ac225930e2c8d44806bbaf0638", null ],
    [ "fbo_", "interface_c_c_grabber.html#ab646339c6b9020deebec014ee6bd2420", null ],
    [ "oldClearColor_", "interface_c_c_grabber.html#ae5f62850dd440e41e5c098998145632d", null ],
    [ "oldFBO_", "interface_c_c_grabber.html#a70f80905904002ec39e50c8d38e616f9", null ]
];