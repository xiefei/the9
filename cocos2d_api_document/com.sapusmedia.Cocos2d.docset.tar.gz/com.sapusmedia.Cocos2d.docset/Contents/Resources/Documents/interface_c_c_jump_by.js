var interface_c_c_jump_by =
[
    [ "actionWithDuration:position:height:jumps:", "interface_c_c_jump_by.html#ad59992b4e3b9198ed78a6ff4539000fa", null ],
    [ "initWithDuration:position:height:jumps:", "interface_c_c_jump_by.html#ad94b2075916a71183cc339be8e0e5660", null ],
    [ "delta_", "interface_c_c_jump_by.html#a4155293b23d8dd175de23860f7f63013", null ],
    [ "height_", "interface_c_c_jump_by.html#a854f06bdf7738a76cb6f2a527c0ab10f", null ],
    [ "jumps_", "interface_c_c_jump_by.html#a46884c98841fca9e28e7f08626ecced5", null ],
    [ "startPosition_", "interface_c_c_jump_by.html#af86c9ec10f8a7c7a73caff8ccf083383", null ]
];