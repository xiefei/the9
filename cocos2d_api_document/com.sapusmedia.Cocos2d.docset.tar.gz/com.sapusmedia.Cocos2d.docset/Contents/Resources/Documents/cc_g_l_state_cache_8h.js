var cc_g_l_state_cache_8h =
[
    [ "kCCVertexAttribFlag_None", "cc_g_l_state_cache_8h.html#a0411cd49bb5b71852cecd93bcbf0ca2dadd5be1c9f3a46f0679eea05cf01288c4", null ],
    [ "kCCVertexAttribFlag_Position", "cc_g_l_state_cache_8h.html#a0411cd49bb5b71852cecd93bcbf0ca2da7c678b74676b74b51d13f5bda400337f", null ],
    [ "kCCVertexAttribFlag_Color", "cc_g_l_state_cache_8h.html#a0411cd49bb5b71852cecd93bcbf0ca2dabdfcedb4e2fcda37adca72e09ffdfc28", null ],
    [ "kCCVertexAttribFlag_TexCoords", "cc_g_l_state_cache_8h.html#a0411cd49bb5b71852cecd93bcbf0ca2da3fe916b73648975e9457bf44db855ce2", null ],
    [ "kCCVertexAttribFlag_PosColorTex", "cc_g_l_state_cache_8h.html#a0411cd49bb5b71852cecd93bcbf0ca2da82a8b050defff067ddcbafe4dcf4390c", null ],
    [ "ccGLServerState", "cc_g_l_state_cache_8h.html#af395552034661147c3a67a20581a6294", [
      [ "CC_GL_BLEND", "cc_g_l_state_cache_8h.html#af395552034661147c3a67a20581a6294a4416b2aede2d45e39408e86833add5d0", null ],
      [ "CC_GL_ALL", "cc_g_l_state_cache_8h.html#af395552034661147c3a67a20581a6294a2522ee983500c7c545bdb8d335896a43", null ]
    ] ],
    [ "ccGLActiveTexture", "cc_g_l_state_cache_8h.html#a5d87d6da9f94ccc1caeb1c0a9ce910d9", null ],
    [ "ccGLBindTexture2D", "cc_g_l_state_cache_8h.html#a8a0c0bb2650d111dd2f155070b6b4714", null ],
    [ "ccGLBlendFunc", "cc_g_l_state_cache_8h.html#a38791a1d8d0b920a4138b2554015a028", null ],
    [ "ccGLDeleteProgram", "cc_g_l_state_cache_8h.html#ac28fe4b928ce2b80c8106c9f17db749b", null ],
    [ "ccGLDeleteTexture", "cc_g_l_state_cache_8h.html#ae6ea167c856dcd40971ad4ce237253d5", null ],
    [ "ccGLEnable", "cc_g_l_state_cache_8h.html#aec3952a24e906ffbce477954278eaded", null ],
    [ "ccGLEnableVertexAttribs", "cc_g_l_state_cache_8h.html#a1e1aad887ead71522a0ee83764f9236a", null ],
    [ "ccGLGetActiveTexture", "cc_g_l_state_cache_8h.html#a14f6944cb38d6d7581bf997ca1928ceb", null ],
    [ "ccGLInvalidateStateCache", "cc_g_l_state_cache_8h.html#ab808c729c8978d63a915fb2784abeb2c", null ],
    [ "ccGLUseProgram", "cc_g_l_state_cache_8h.html#a353f977869c5601333c47f0c939db3da", null ],
    [ "ccSetProjectionMatrixDirty", "cc_g_l_state_cache_8h.html#a343497226a87e4ece563eae54d23bb5f", null ]
];