var interface_c_c_animation_frame =
[
    [ "initWithSpriteFrame:delayUnits:userInfo:", "interface_c_c_animation_frame.html#a7d987b4f51cb75018382a2bb042d7d2d", null ],
    [ "delayUnits_", "interface_c_c_animation_frame.html#a66659ce8832521a9e397e58b4bf82ff7", null ],
    [ "spriteFrame_", "interface_c_c_animation_frame.html#a1dbdcf878fbfee68fc87f83cd924dc2a", null ],
    [ "userInfo_", "interface_c_c_animation_frame.html#aed50d5526e3770e6918b568692fb29e0", null ],
    [ "delayUnits", "interface_c_c_animation_frame.html#aa03ce459c21bb02117a0136d13f5b7ff", null ],
    [ "spriteFrame", "interface_c_c_animation_frame.html#a42391105614626578802667da59120fc", null ],
    [ "userInfo", "interface_c_c_animation_frame.html#a9eb75cd1e56aafd7d4041ca0a50598b4", null ]
];