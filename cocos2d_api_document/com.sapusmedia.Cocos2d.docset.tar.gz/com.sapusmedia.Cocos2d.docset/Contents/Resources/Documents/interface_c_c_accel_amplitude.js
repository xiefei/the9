var interface_c_c_accel_amplitude =
[
    [ "actionWithAction:duration:", "interface_c_c_accel_amplitude.html#a07d554e0977209015d110872ddac8300", null ],
    [ "initWithAction:duration:", "interface_c_c_accel_amplitude.html#afbd7141d48a2074757bdba039a9bd9d1", null ],
    [ "other_", "interface_c_c_accel_amplitude.html#a8d9747727042d48a2f1ac48c6fcd742e", null ],
    [ "rate_", "interface_c_c_accel_amplitude.html#a09ddb8901c9583968a38e63cff62962c", null ],
    [ "rate", "interface_c_c_accel_amplitude.html#af89107d62a2367e270b6be31b10785b1", null ]
];