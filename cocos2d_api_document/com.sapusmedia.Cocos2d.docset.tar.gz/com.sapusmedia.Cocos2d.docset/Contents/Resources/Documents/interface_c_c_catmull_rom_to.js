var interface_c_c_catmull_rom_to =
[
    [ "actionWithDuration:points:", "interface_c_c_catmull_rom_to.html#ab107d7117fa2131a0574f97efa617949", null ],
    [ "initWithDuration:points:", "interface_c_c_catmull_rom_to.html#a4fe8a81d1d1d96f45001ffc59827a71c", null ]
];