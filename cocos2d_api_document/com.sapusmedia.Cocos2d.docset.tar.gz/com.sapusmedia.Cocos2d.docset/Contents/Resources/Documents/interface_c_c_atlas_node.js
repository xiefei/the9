var interface_c_c_atlas_node =
[
    [ "atlasWithTileFile:tileWidth:tileHeight:itemsToRender:", "interface_c_c_atlas_node.html#a18b0064296f3321ac2fe8401ad81257d", null ],
    [ "initWithTileFile:tileWidth:tileHeight:itemsToRender:", "interface_c_c_atlas_node.html#adf18f68b5e35d7330f8bc60594c25663", null ],
    [ "updateAtlasValues", "interface_c_c_atlas_node.html#a044492e0d71cfae2f6e7c3070a4d45c9", null ],
    [ "blendFunc_", "interface_c_c_atlas_node.html#a3f875464bde247975fa615ed1279b750", null ],
    [ "color_", "interface_c_c_atlas_node.html#ac33740853834826d6be7844db4b23eae", null ],
    [ "colorUnmodified_", "interface_c_c_atlas_node.html#a0fb1dc59667a4dd26a0d8695859ab121", null ],
    [ "itemHeight_", "interface_c_c_atlas_node.html#aafe66f645314ceb9f8865460a53667d9", null ],
    [ "itemsPerColumn_", "interface_c_c_atlas_node.html#adb0e407980f08bbc8b6353624a126bf6", null ],
    [ "itemsPerRow_", "interface_c_c_atlas_node.html#a25a082efb3bdcb06d20eeca917547c0a", null ],
    [ "itemWidth_", "interface_c_c_atlas_node.html#a9739e5ec5abc46fd002a3f4005fb974a", null ],
    [ "opacity_", "interface_c_c_atlas_node.html#a755ce04467cb5bcbd00220299aa5cd65", null ],
    [ "opacityModifyRGB_", "interface_c_c_atlas_node.html#a577d29439e711969398c2602205a6d67", null ],
    [ "quadsToDraw_", "interface_c_c_atlas_node.html#aea2c3d40bd098eee933378530bf64b16", null ],
    [ "textureAtlas_", "interface_c_c_atlas_node.html#ae4ec633b604d52ebe29189182a3f5aec", null ],
    [ "uniformColor_", "interface_c_c_atlas_node.html#a708e4eff72fa1863cf1599c2d7b42c98", null ],
    [ "blendFunc", "interface_c_c_atlas_node.html#a95ccf1026e010ab1ed2577cf0e6a01cf", null ],
    [ "color", "interface_c_c_atlas_node.html#af32feef5f87a1163f6f432bf524227e9", null ],
    [ "opacity", "interface_c_c_atlas_node.html#affce9833612d523a1f3658dd40c08c1f", null ],
    [ "quadsToDraw", "interface_c_c_atlas_node.html#aef4af546b58afdaa2d75cac3ee7d60fe", null ],
    [ "textureAtlas", "interface_c_c_atlas_node.html#ad1cf740dfe711b0875533aef41afd507", null ]
];