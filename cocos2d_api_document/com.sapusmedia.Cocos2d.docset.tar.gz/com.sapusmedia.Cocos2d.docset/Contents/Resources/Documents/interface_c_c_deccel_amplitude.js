var interface_c_c_deccel_amplitude =
[
    [ "actionWithAction:duration:", "interface_c_c_deccel_amplitude.html#ae877f5b01e6e902eb76047f8feaeae94", null ],
    [ "initWithAction:duration:", "interface_c_c_deccel_amplitude.html#a45919a8400869994260dac940cc9fec4", null ],
    [ "other_", "interface_c_c_deccel_amplitude.html#a302e45f0ac5c78676ca626178e756621", null ],
    [ "rate_", "interface_c_c_deccel_amplitude.html#af40a17b010e3660dbb4725f55ab32bc2", null ],
    [ "rate", "interface_c_c_deccel_amplitude.html#a852e0ca5c3ea10a23a0ad7cf4be3c907", null ]
];