var interface_c_c_call_func_n_d =
[
    [ "actionWithTarget:selector:data:", "interface_c_c_call_func_n_d.html#a7a11c02c792394d63b4a5c42c1cf6cdb", null ],
    [ "initWithTarget:selector:data:", "interface_c_c_call_func_n_d.html#a5168ae06674520c5769d24ee8618e793", null ],
    [ "callbackMethod_", "interface_c_c_call_func_n_d.html#aa41ee99280e2cbaa9540b4aa823634bd", null ],
    [ "data_", "interface_c_c_call_func_n_d.html#a86828a279502fd98c7aacdbd72c1863f", null ],
    [ "callbackMethod", "interface_c_c_call_func_n_d.html#aac7c0913e85a9a4046d36e960bee2ec2", null ]
];