var interface_c_c_configuration =
[
    [ "checkForGLExtension:", "interface_c_c_configuration.html#ad2e12cee4ed69634622b1626246b4554", null ],
    [ "sharedConfiguration", "interface_c_c_configuration.html#ac72a28a648a05b877378ef484aa4ffd8", null ],
    [ "maxModelviewStackDepth_", "interface_c_c_configuration.html#aa77fb0043dd566ee26bb9308904d005d", null ],
    [ "maxSamplesAllowed_", "interface_c_c_configuration.html#a8fb99c6defe6ec30317f025dbc551936", null ],
    [ "maxTextureSize_", "interface_c_c_configuration.html#ab4175ac94742ce8698f9667010776179", null ],
    [ "maxTextureUnits_", "interface_c_c_configuration.html#a1028ed49d1689d40c43850fa71969541", null ],
    [ "OSVersion_", "interface_c_c_configuration.html#a679b02885208f310a009af7244ab297d", null ],
    [ "supportsBGRA8888_", "interface_c_c_configuration.html#ad21fa0efb17153f71be4bd11c29aeb4a", null ],
    [ "supportsDiscardFramebuffer_", "interface_c_c_configuration.html#ac812e26c8d80d1aed54acd5e2933b560", null ],
    [ "supportsNPOT_", "interface_c_c_configuration.html#abdabd438e9dfdf1814e0689b81f0b442", null ],
    [ "supportsPVRTC_", "interface_c_c_configuration.html#a45c73ee39ac446df0c51a913f05622e4", null ],
    [ "supportsShareableVAO_", "interface_c_c_configuration.html#a61e3c63edd25f03f96943c66d6d5d919", null ],
    [ "maxModelviewStackDepth", "interface_c_c_configuration.html#a7c7b06ab48d5f5e55aff3681aa77ab91", null ],
    [ "maxTextureSize", "interface_c_c_configuration.html#a247ddc51eeee101083716888f52c1ccb", null ],
    [ "maxTextureUnits", "interface_c_c_configuration.html#a1fab22b6a96c7b4b85e120df26291612", null ],
    [ "OSVersion", "interface_c_c_configuration.html#a702f8067990021f6ad4366c8ea8033f4", null ],
    [ "supportsBGRA8888", "interface_c_c_configuration.html#a7bf4ed17273b9cf0e24333444bf03bb9", null ],
    [ "supportsDiscardFramebuffer", "interface_c_c_configuration.html#a458fe46160b0950264f13aecd60ecf60", null ],
    [ "supportsNPOT", "interface_c_c_configuration.html#a9de282307e774c7274bead01371c242e", null ],
    [ "supportsPVRTC", "interface_c_c_configuration.html#a2d9f6433a251a61dfb1b120aed830840", null ],
    [ "supportsShareableVAO", "interface_c_c_configuration.html#a9f955f4b66edfc2391c08df18cddad62", null ]
];