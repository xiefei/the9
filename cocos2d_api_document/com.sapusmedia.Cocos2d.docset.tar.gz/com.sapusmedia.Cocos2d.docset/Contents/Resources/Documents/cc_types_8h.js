var cc_types_8h =
[
    [ "ccColor3B", "structcc_color3_b.html", "structcc_color3_b" ],
    [ "ccColor4B", "structcc_color4_b.html", "structcc_color4_b" ],
    [ "ccColor4F", "structcc_color4_f.html", "structcc_color4_f" ],
    [ "ccVertex2F", "structcc_vertex2_f.html", "structcc_vertex2_f" ],
    [ "ccVertex3F", "structcc_vertex3_f.html", "structcc_vertex3_f" ],
    [ "ccTex2F", "structcc_tex2_f.html", "structcc_tex2_f" ],
    [ "ccPointSprite", "structcc_point_sprite.html", "structcc_point_sprite" ],
    [ "ccQuad2", "structcc_quad2.html", "structcc_quad2" ],
    [ "ccQuad3", "structcc_quad3.html", "structcc_quad3" ],
    [ "ccGridSize", "structcc_grid_size.html", "structcc_grid_size" ],
    [ "ccV2F_C4B_T2F", "structcc_v2_f___c4_b___t2_f.html", "structcc_v2_f___c4_b___t2_f" ],
    [ "ccV2F_C4F_T2F", "structcc_v2_f___c4_f___t2_f.html", "structcc_v2_f___c4_f___t2_f" ],
    [ "ccV3F_C4F_T2F", "structcc_v3_f___c4_f___t2_f.html", "structcc_v3_f___c4_f___t2_f" ],
    [ "ccV3F_C4F_T2F_Quad", "structcc_v3_f___c4_f___t2_f___quad.html", "structcc_v3_f___c4_f___t2_f___quad" ],
    [ "ccV3F_C4B_T2F", "structcc_v3_f___c4_b___t2_f.html", "structcc_v3_f___c4_b___t2_f" ],
    [ "ccV2F_C4B_T2F_Quad", "structcc_v2_f___c4_b___t2_f___quad.html", "structcc_v2_f___c4_b___t2_f___quad" ],
    [ "ccV3F_C4B_T2F_Quad", "structcc_v3_f___c4_b___t2_f___quad.html", "structcc_v3_f___c4_b___t2_f___quad" ],
    [ "ccV2F_C4F_T2F_Quad", "structcc_v2_f___c4_f___t2_f___quad.html", "structcc_v2_f___c4_f___t2_f___quad" ],
    [ "ccBlendFunc", "structcc_blend_func.html", "structcc_blend_func" ],
    [ "ccMat4", "cc_types_8h.html#a886dd933631021e3415464d895faeaff", null ],
    [ "ccTime", "cc_types_8h.html#ae6c674aac4bfb46a4e6cb1e89bb66b4f", null ],
    [ "CCLineBreakMode", "cc_types_8h.html#a08acef9a1b6541728d486ff7eae99e91", [
      [ "kCCLineBreakModeWordWrap", "cc_types_8h.html#a08acef9a1b6541728d486ff7eae99e91a8f7c8fac98ad2b9339650a56582c242e", null ],
      [ "kCCLineBreakModeCharacterWrap", "cc_types_8h.html#a08acef9a1b6541728d486ff7eae99e91a63ae526aee22dfd7ae5a7a94af36e0e6", null ],
      [ "kCCLineBreakModeClip", "cc_types_8h.html#a08acef9a1b6541728d486ff7eae99e91a3395bd267cf55a0993bfbebb8c7a0201", null ],
      [ "kCCLineBreakModeHeadTruncation", "cc_types_8h.html#a08acef9a1b6541728d486ff7eae99e91ab191b09104a97a2acd2424d099f041d7", null ],
      [ "kCCLineBreakModeTailTruncation", "cc_types_8h.html#a08acef9a1b6541728d486ff7eae99e91a33c2eb58d47acf946d4836a92674ce52", null ],
      [ "kCCLineBreakModeMiddleTruncation", "cc_types_8h.html#a08acef9a1b6541728d486ff7eae99e91abb60410d3e4cd42aede97456f30cf00b", null ]
    ] ],
    [ "ccResolutionType", "cc_types_8h.html#a3fccc5ae3efabdf2bb0aebafe9620f5d", [
      [ "kCCResolutionUnknown", "cc_types_8h.html#a3fccc5ae3efabdf2bb0aebafe9620f5da288b7b377ccb4311d58d9119e084454e", null ]
    ] ],
    [ "CCTextAlignment", "cc_types_8h.html#aa56b958f0cc9bdec20a15ed6bea3d0f1", [
      [ "kCCTextAlignmentLeft", "cc_types_8h.html#aa56b958f0cc9bdec20a15ed6bea3d0f1aa097bc0b383205a1d398dee3312f8c90", null ],
      [ "kCCTextAlignmentCenter", "cc_types_8h.html#aa56b958f0cc9bdec20a15ed6bea3d0f1a6eb550d3015195c82b22ad5810274a7d", null ],
      [ "kCCTextAlignmentRight", "cc_types_8h.html#aa56b958f0cc9bdec20a15ed6bea3d0f1a50c42591dcdb835fa83dab0868052c90", null ]
    ] ],
    [ "CCVerticalTextAlignment", "cc_types_8h.html#a7ec81bc3a093bf8c36b996174d97dda3", [
      [ "kCCVerticalTextAlignmentTop", "cc_types_8h.html#a7ec81bc3a093bf8c36b996174d97dda3a446c5f1f88a1b086d8b7b47a652496ac", null ],
      [ "kCCVerticalTextAlignmentCenter", "cc_types_8h.html#a7ec81bc3a093bf8c36b996174d97dda3a826d63d7cce0d2c4f65c13dd1617d4cc", null ],
      [ "kCCVerticalTextAlignmentBottom", "cc_types_8h.html#a7ec81bc3a093bf8c36b996174d97dda3a344968d311eb1e0eac2a7ea1b5810311", null ]
    ] ],
    [ "ccc3", "cc_types_8h.html#a7a97c272c95e1b3a1e0b56777254fb3a", null ],
    [ "ccc4", "cc_types_8h.html#a664b22586e2357db8ed50dc6230cbcb2", null ],
    [ "ccc4f", "cc_types_8h.html#a0a86aee928fdc340e4fd9e9ce1c6ffa8", null ],
    [ "ccc4FEqual", "cc_types_8h.html#a4934286234e580892dadf1ed14c6b602", null ],
    [ "ccc4FFromccc3B", "cc_types_8h.html#a689655db556e0cd4c3c8c8f5f6dbdeb6", null ],
    [ "ccc4FFromccc4B", "cc_types_8h.html#a049b9f0d2b6a4f4c11b024302ce1805e", null ],
    [ "ccg", "cc_types_8h.html#ae455ac18f9838d9fced6d44fef7bdb67", null ],
    [ "ccBLACK", "cc_types_8h.html#a36e7bafc07dc72f609107da4dddcc581", null ],
    [ "ccBLUE", "cc_types_8h.html#a12ad9533656ef71d339dce02a9f77416", null ],
    [ "ccGRAY", "cc_types_8h.html#a29f3ee790497b0cd519863dbdeb5ba43", null ],
    [ "ccGREEN", "cc_types_8h.html#a03c5a8a724741a11afd73fb4fa17fc24", null ],
    [ "ccMAGENTA", "cc_types_8h.html#a7571a1f6dd9f2144930d5649742d8533", null ],
    [ "ccORANGE", "cc_types_8h.html#aef93840bfd2e4fa246def072f64bb822", null ],
    [ "ccRED", "cc_types_8h.html#aab9d1536703c330ae34444020f1f5f14", null ],
    [ "ccWHITE", "cc_types_8h.html#ae24123f6ece326ce5751dd272cb4b24d", null ],
    [ "ccYELLOW", "cc_types_8h.html#a05b71a73a87e357e573ce4d73f9a456f", null ]
];