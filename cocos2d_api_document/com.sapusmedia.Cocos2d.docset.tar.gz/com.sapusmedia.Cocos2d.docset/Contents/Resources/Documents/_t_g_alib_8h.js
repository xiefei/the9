var _t_g_alib_8h =
[
    [ "tImageTGA", "structt_image_t_g_a.html", "structt_image_t_g_a" ],
    [ "TGA_OK", "_t_g_alib_8h.html#a94798fdadfbf49a7c658ace669a1d310aa12b3056671d5d2d94fb7f7a2281aa7d", null ],
    [ "TGA_ERROR_FILE_OPEN", "_t_g_alib_8h.html#a94798fdadfbf49a7c658ace669a1d310ad6eeba399e06c468226f468b44f85ef5", null ],
    [ "TGA_ERROR_READING_FILE", "_t_g_alib_8h.html#a94798fdadfbf49a7c658ace669a1d310a208694558561713b31e84e7b3f545a3d", null ],
    [ "TGA_ERROR_INDEXED_COLOR", "_t_g_alib_8h.html#a94798fdadfbf49a7c658ace669a1d310aea55e75ae70e5162453a52f036f42937", null ],
    [ "TGA_ERROR_MEMORY", "_t_g_alib_8h.html#a94798fdadfbf49a7c658ace669a1d310a06063b31f5406b4d8946eb3218c659ad", null ],
    [ "TGA_ERROR_COMPRESSED_FILE", "_t_g_alib_8h.html#a94798fdadfbf49a7c658ace669a1d310ae08de9e0d7e7e8d934fdf7d246ebeeed", null ],
    [ "tgaDestroy", "_t_g_alib_8h.html#a32e91a02310314624879397d928fe69c", null ],
    [ "tgaLoad", "_t_g_alib_8h.html#ad350c7cfd82d472520e62e5b70f8a1d1", null ],
    [ "tgaLoadHeader", "_t_g_alib_8h.html#ae4e4a746c9d9122a2a00e9ccff4b3b88", null ],
    [ "tgaLoadImageData", "_t_g_alib_8h.html#a3004dc7778923df2e03e727d34d74760", null ],
    [ "tgaRGBtogreyscale", "_t_g_alib_8h.html#ac6864d3fdf905f0f6c4adc08f5b96dae", null ]
];