var interface_c_c_catmull_rom_by =
[
    [ "actionWithDuration:points:", "interface_c_c_catmull_rom_by.html#ad1173fd5720624fcac84d0f1bba2983d", null ],
    [ "initWithDuration:points:", "interface_c_c_catmull_rom_by.html#afcf10d30ea73b472eed3770ac53a813a", null ]
];