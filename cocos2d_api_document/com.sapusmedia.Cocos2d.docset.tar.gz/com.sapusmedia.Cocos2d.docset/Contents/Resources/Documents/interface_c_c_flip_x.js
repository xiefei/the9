var interface_c_c_flip_x =
[
    [ "actionWithFlipX:", "interface_c_c_flip_x.html#a35cf9892d0699f2a9b76d60510d456c3", null ],
    [ "initWithFlipX:", "interface_c_c_flip_x.html#a890f62de55257d753d3a9f0aec9c480a", null ],
    [ "flipX", "interface_c_c_flip_x.html#a165c6ebebed6525884203ef0ef6eb0c1", null ]
];