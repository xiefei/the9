var category_c_c_texture2_d_07_drawing_08 =
[
    [ "drawAtPoint:", "category_c_c_texture2_d_07_drawing_08.html#a6bd05327db057f1e318920fad6d5f84e", null ],
    [ "drawInRect:", "category_c_c_texture2_d_07_drawing_08.html#a793f50f586136d10c6e2ca3882b22cda", null ]
];