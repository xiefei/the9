var interface_c_c_cardinal_spline_to =
[
    [ "actionWithDuration:points:tension:", "interface_c_c_cardinal_spline_to.html#ac7c46c993b98b2ffc427349a834d1abd", null ],
    [ "initWithDuration:points:tension:", "interface_c_c_cardinal_spline_to.html#ada9539c4211dc170497809711d4d5c22", null ],
    [ "deltaT_", "interface_c_c_cardinal_spline_to.html#ac3c676a4e25fe0202576efa42484f98a", null ],
    [ "points_", "interface_c_c_cardinal_spline_to.html#ac932f71ff3bd127c0c414bef9bc33290", null ],
    [ "tension_", "interface_c_c_cardinal_spline_to.html#ab1f39c734249c14d9481f9be9f93c111", null ],
    [ "points", "interface_c_c_cardinal_spline_to.html#a580b5c52ae10ea8a920fcf1550bbf731", null ]
];