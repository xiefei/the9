var interface_c_c_call_func_o =
[
    [ "actionWithTarget:selector:object:", "interface_c_c_call_func_o.html#a2444389a377c5baf05bec11db16badb6", null ],
    [ "initWithTarget:selector:object:", "interface_c_c_call_func_o.html#a449da6db7ef0d52e2fa5794a8276f85b", null ],
    [ "object_", "interface_c_c_call_func_o.html#a5ed49e2b56d9dae47dbbf151f7e02192", null ],
    [ "object", "interface_c_c_call_func_o.html#ab74a42b17f6fa277e54b9cd466960d82", null ]
];