var cc_config_8h =
[
    [ "CC_DIRECTOR_IOS_USE_BACKGROUND_THREAD", "cc_config_8h.html#a42fbdd9c1ad63b5934b6779fe43bd5fb", null ],
    [ "CC_DIRECTOR_MAC_THREAD", "cc_config_8h.html#a4c860cd9f7a81990da48895680241959", null ],
    [ "CC_DIRECTOR_STATS_INTERVAL", "cc_config_8h.html#acc5a20ca67e535a3f0c4df065812be15", null ],
    [ "CC_DIRECTOR_STATS_POSITION", "cc_config_8h.html#a1e1efd5ccba0eca8ce67cd48bfe464b4", null ],
    [ "CC_ENABLE_GL_STATE_CACHE", "cc_config_8h.html#a681e28ff1c3be58c23e7d5edbf676ac2", null ],
    [ "CC_ENABLE_PROFILERS", "cc_config_8h.html#a98d1621f0191439c39d567b99a8693fa", null ],
    [ "CC_FIX_ARTIFACTS_BY_STRECHING_TEXEL", "cc_config_8h.html#aa1dbba32b8583567435406fe7b964003", null ],
    [ "CC_LABELATLAS_DEBUG_DRAW", "cc_config_8h.html#a685f101466e5362ee6b6a9fb6a215714", null ],
    [ "CC_LABELBMFONT_DEBUG_DRAW", "cc_config_8h.html#af56a44d7647fb541c5a51bccc7d9f38c", null ],
    [ "CC_MAC_USE_DISPLAY_LINK_THREAD", "cc_config_8h.html#a380ea79ef7a5ee6c681c66df503c459a", null ],
    [ "CC_MAC_USE_MAIN_THREAD", "cc_config_8h.html#afcf6f2ffccf12cd2a93da89bee5fc6f2", null ],
    [ "CC_MAC_USE_OWN_THREAD", "cc_config_8h.html#ab25ff3f014515a5e4210ff026a9b87d7", null ],
    [ "CC_NODE_RENDER_SUBPIXEL", "cc_config_8h.html#ab13e7747317d74c8d23746de658da13d", null ],
    [ "CC_SPRITE_DEBUG_DRAW", "cc_config_8h.html#a1be378e696dde019aef27ac742167ddf", null ],
    [ "CC_SPRITEBATCHNODE_RENDER_SUBPIXEL", "cc_config_8h.html#a63b18e29ae8fa92b9a3392108b4bfd06", null ],
    [ "CC_TEXTURE_ATLAS_USE_TRIANGLE_STRIP", "cc_config_8h.html#a2e39f3f8da2f5ee5ac35abe1659d999b", null ],
    [ "CC_TEXTURE_ATLAS_USE_VAO", "cc_config_8h.html#a843586bad8c4678765f24e077d06639d", null ],
    [ "CC_USE_LA88_LABELS", "cc_config_8h.html#ac18846a5ddb26b6a8e38f24d97790234", null ]
];